import * as firebase from "firebase";
require("@firebase/firestore");

const firebaseConfig = {
  apiKey: "AIzaSyCdSeN3bwKdCHN6fsYnQIJ4LtDDHqqO4vw",
  authDomain: "wily-app-bd3a0.firebaseapp.com",
  projectId: "wily-app-bd3a0",
  storageBucket: "wily-app-bd3a0.appspot.com",
  messagingSenderId: "698411374259",
  appId: "1:698411374259:web:b432debe0c697ed1b1c2c6"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export default firebase.firestore();
